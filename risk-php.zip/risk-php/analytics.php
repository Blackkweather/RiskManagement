<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics Dashboard - RiskGuard Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .navbar .nav-links {
            display: flex;
            gap: 20px;
        }

        .navbar .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background 0.3s;
        }

        .navbar .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }

        .page-header {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-header h1 {
            color: #2d3748;
            font-size: 2.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .date-filter {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .date-filter select,
        .date-filter input {
            padding: 8px 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .stat-card .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.8;
        }

        .stat-card .value {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }

        .stat-card .label {
            color: #718096;
            font-size: 1rem;
            margin-bottom: 1rem;
        }

        .stat-card .change {
            font-size: 0.9rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
        }

        .stat-card .change.positive {
            color: #38a169;
        }

        .stat-card .change.negative {
            color: #e53e3e;
        }

        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .chart-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .chart-title {
            color: #2d3748;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .chart-canvas {
            position: relative;
            height: 300px;
        }

        .full-width-chart {
            grid-column: 1 / -1;
        }

        .risk-matrix {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .matrix-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 2px;
            margin-top: 1rem;
        }

        .matrix-cell {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            border-radius: 4px;
        }

        .matrix-header {
            background: #4a5568;
            color: white;
        }

        .matrix-low {
            background: #68d391;
            color: #1a202c;
        }

        .matrix-medium {
            background: #fbd38d;
            color: #1a202c;
        }

        .matrix-high {
            background: #fc8181;
            color: white;
        }

        .matrix-critical {
            background: #e53e3e;
            color: white;
        }

        .trends-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        .trend-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }

        .trend-item:last-child {
            border-bottom: none;
        }

        .trend-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }

        .trend-content {
            flex: 1;
        }

        .trend-title {
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 0.25rem;
        }

        .trend-description {
            color: #718096;
            font-size: 0.9rem;
        }

        .export-section {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .export-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 1rem;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #4a5568;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        @media (max-width: 768px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .trends-section {
                grid-template-columns: 1fr;
            }
            
            .page-header {
                flex-direction: column;
                gap: 1rem;
            }
            
            .export-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-shield-alt"></i>
            RiskGuard Pro
        </div>
        <div class="nav-links">
            <a href="index.php"><i class="fas fa-home"></i> Dashboard</a>
            <a href="clients.php"><i class="fas fa-building"></i> Clients</a>
            <a href="risks.php"><i class="fas fa-exclamation-triangle"></i> Risks</a>
            <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </div>
    </nav>

    <div class="container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="fas fa-chart-line"></i>
                Analytics Dashboard
            </h1>
            <div class="date-filter">
                <select id="timeRange">
                    <option value="7">Last 7 days</option>
                    <option value="30" selected>Last 30 days</option>
                    <option value="90">Last 90 days</option>
                    <option value="365">Last year</option>
                </select>
                <input type="date" id="startDate">
                <input type="date" id="endDate">
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon" style="color: #667eea;">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="value">247</div>
                <div class="label">Total Risks</div>
                <div class="change positive">
                    <i class="fas fa-arrow-up"></i>
                    +12% from last month
                </div>
            </div>

            <div class="stat-card">
                <div class="icon" style="color: #e53e3e;">
                    <i class="fas fa-fire"></i>
                </div>
                <div class="value">23</div>
                <div class="label">Critical Risks</div>
                <div class="change negative">
                    <i class="fas fa-arrow-down"></i>
                    -8% from last month
                </div>
            </div>

            <div class="stat-card">
                <div class="icon" style="color: #38a169;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="value">89%</div>
                <div class="label">Mitigation Rate</div>
                <div class="change positive">
                    <i class="fas fa-arrow-up"></i>
                    +5% from last month
                </div>
            </div>

            <div class="stat-card">
                <div class="icon" style="color: #d69e2e;">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="value">4.2</div>
                <div class="label">Avg. Response Time (days)</div>
                <div class="change positive">
                    <i class="fas fa-arrow-down"></i>
                    -1.3 days improved
                </div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-grid">
            <div class="chart-container">
                <h2 class="chart-title">
                    <i class="fas fa-chart-line"></i>
                    Risk Trends Over Time
                </h2>
                <div class="chart-canvas">
                    <canvas id="riskTrendsChart"></canvas>
                </div>
            </div>

            <div class="chart-container">
                <h2 class="chart-title">
                    <i class="fas fa-chart-pie"></i>
                    Risk Distribution
                </h2>
                <div class="chart-canvas">
                    <canvas id="riskDistributionChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Risk Matrix -->
        <div class="risk-matrix">
            <h2 class="chart-title">
                <i class="fas fa-th"></i>
                Risk Heat Map Matrix
            </h2>
            <div class="matrix-grid">
                <div class="matrix-cell matrix-header"></div>
                <div class="matrix-cell matrix-header">Very Low</div>
                <div class="matrix-cell matrix-header">Low</div>
                <div class="matrix-cell matrix-header">Medium</div>
                <div class="matrix-cell matrix-header">High</div>
                <div class="matrix-cell matrix-header">Very High</div>
                
                <div class="matrix-cell matrix-header">Very High</div>
                <div class="matrix-cell matrix-medium">2</div>
                <div class="matrix-cell matrix-high">8</div>
                <div class="matrix-cell matrix-critical">15</div>
                <div class="matrix-cell matrix-critical">23</div>
                <div class="matrix-cell matrix-critical">12</div>
                
                <div class="matrix-cell matrix-header">High</div>
                <div class="matrix-cell matrix-low">1</div>
                <div class="matrix-cell matrix-medium">5</div>
                <div class="matrix-cell matrix-high">12</div>
                <div class="matrix-cell matrix-high">18</div>
                <div class="matrix-cell matrix-critical">9</div>
                
                <div class="matrix-cell matrix-header">Medium</div>
                <div class="matrix-cell matrix-low">3</div>
                <div class="matrix-cell matrix-low">7</div>
                <div class="matrix-cell matrix-medium">14</div>
                <div class="matrix-cell matrix-medium">11</div>
                <div class="matrix-cell matrix-high">6</div>
                
                <div class="matrix-cell matrix-header">Low</div>
                <div class="matrix-cell matrix-low">8</div>
                <div class="matrix-cell matrix-low">12</div>
                <div class="matrix-cell matrix-low">9</div>
                <div class="matrix-cell matrix-medium">4</div>
                <div class="matrix-cell matrix-medium">2</div>
                
                <div class="matrix-cell matrix-header">Very Low</div>
                <div class="matrix-cell matrix-low">15</div>
                <div class="matrix-cell matrix-low">10</div>
                <div class="matrix-cell matrix-low">6</div>
                <div class="matrix-cell matrix-low">3</div>
                <div class="matrix-cell matrix-low">1</div>
            </div>
        </div>

        <!-- Additional Charts -->
        <div class="chart-container full-width-chart">
            <h2 class="chart-title">
                <i class="fas fa-chart-bar"></i>
                Risk Categories Analysis
            </h2>
            <div class="chart-canvas">
                <canvas id="categoriesChart"></canvas>
            </div>
        </div>

        <!-- Trends and Insights -->
        <div class="trends-section">
            <div class="chart-container">
                <h2 class="chart-title">
                    <i class="fas fa-trending-up"></i>
                    Key Insights
                </h2>
                
                <div class="trend-item">
                    <div class="trend-icon" style="background: #38a169;">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <div class="trend-content">
                        <div class="trend-title">Critical Risks Decreased</div>
                        <div class="trend-description">8% reduction in critical risks this month</div>
                    </div>
                </div>

                <div class="trend-item">
                    <div class="trend-icon" style="background: #667eea;">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="trend-content">
                        <div class="trend-title">Faster Response Times</div>
                        <div class="trend-description">Average response improved by 1.3 days</div>
                    </div>
                </div>

                <div class="trend-item">
                    <div class="trend-icon" style="background: #d69e2e;">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="trend-content">
                        <div class="trend-title">Technology Risks Rising</div>
                        <div class="trend-description">15% increase in technology-related risks</div>
                    </div>
                </div>

                <div class="trend-item">
                    <div class="trend-icon" style="background: #38a169;">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="trend-content">
                        <div class="trend-title">Controls Effectiveness</div>
                        <div class="trend-description">89% of implemented controls are effective</div>
                    </div>
                </div>
            </div>

            <div class="chart-container">
                <h2 class="chart-title">
                    <i class="fas fa-chart-area"></i>
                    Mitigation Progress
                </h2>
                <div class="chart-canvas">
                    <canvas id="mitigationChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Export Section -->
        <div class="export-section">
            <h2 class="chart-title">
                <i class="fas fa-download"></i>
                Export Analytics
            </h2>
            <p style="color: #718096; margin-bottom: 1rem;">
                Download comprehensive analytics reports in various formats
            </p>
            <div class="export-buttons">
                <button class="btn btn-primary">
                    <i class="fas fa-file-pdf"></i>
                    Export PDF Report
                </button>
                <button class="btn btn-secondary">
                    <i class="fas fa-file-excel"></i>
                    Export Excel
                </button>
                <button class="btn btn-secondary">
                    <i class="fas fa-file-csv"></i>
                    Export CSV
                </button>
                <button class="btn btn-secondary">
                    <i class="fas fa-image"></i>
                    Export Charts
                </button>
            </div>
        </div>
    </div>

    <script>
        // Risk Trends Chart
        const riskTrendsCtx = document.getElementById('riskTrendsChart').getContext('2d');
        new Chart(riskTrendsCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Total Risks',
                    data: [180, 195, 210, 225, 240, 247],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Critical Risks',
                    data: [35, 32, 28, 25, 25, 23],
                    borderColor: '#e53e3e',
                    backgroundColor: 'rgba(229, 62, 62, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Risk Distribution Chart
        const riskDistCtx = document.getElementById('riskDistributionChart').getContext('2d');
        new Chart(riskDistCtx, {
            type: 'doughnut',
            data: {
                labels: ['Low', 'Medium', 'High', 'Critical'],
                datasets: [{
                    data: [120, 89, 35, 23],
                    backgroundColor: ['#68d391', '#fbd38d', '#fc8181', '#e53e3e']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Categories Chart
        const categoriesCtx = document.getElementById('categoriesChart').getContext('2d');
        new Chart(categoriesCtx, {
            type: 'bar',
            data: {
                labels: ['Operational', 'Financial', 'Strategic', 'Compliance', 'Technology'],
                datasets: [{
                    label: 'Number of Risks',
                    data: [65, 45, 38, 52, 47],
                    backgroundColor: ['#667eea', '#764ba2', '#38a169', '#d69e2e', '#e53e3e']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Mitigation Chart
        const mitigationCtx = document.getElementById('mitigationChart').getContext('2d');
        new Chart(mitigationCtx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'Mitigation Rate %',
                    data: [75, 82, 86, 89],
                    borderColor: '#38a169',
                    backgroundColor: 'rgba(56, 161, 105, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        // Date filter functionality
        document.getElementById('timeRange').addEventListener('change', function() {
            const days = parseInt(this.value);
            const endDate = new Date();
            const startDate = new Date();
            startDate.setDate(endDate.getDate() - days);
            
            document.getElementById('endDate').value = endDate.toISOString().split('T')[0];
            document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
        });

        // Initialize date inputs
        document.getElementById('timeRange').dispatchEvent(new Event('change'));
    </script>
</body>
</html>

