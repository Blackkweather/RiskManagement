<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - RiskGuard Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .navbar .nav-links {
            display: flex;
            gap: 20px;
        }

        .navbar .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background 0.3s;
        }

        .navbar .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }

        .settings-header {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .settings-header h1 {
            color: #2d3748;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .settings-header p {
            color: #718096;
            font-size: 1.1rem;
        }

        .settings-nav {
            background: white;
            border-radius: 20px;
            padding: 1rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            display: flex;
            gap: 1rem;
            overflow-x: auto;
        }

        .settings-nav button {
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            background: #f7fafc;
            color: #4a5568;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .settings-nav button.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .settings-nav button:hover:not(.active) {
            background: #edf2f7;
        }

        .settings-content {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .settings-section {
            display: none;
        }

        .settings-section.active {
            display: block;
        }

        .section-title {
            color: #2d3748;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2d3748;
            font-weight: 600;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-danger {
            background: #e53e3e;
            color: white;
        }

        .btn-danger:hover {
            background: #c53030;
        }

        .btn-secondary {
            background: #e2e8f0;
            color: #4a5568;
        }

        .btn-secondary:hover {
            background: #cbd5e0;
        }

        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }

        .alert-info {
            background: #ebf8ff;
            border: 1px solid #bee3f8;
            color: #2b6cb0;
        }

        .alert-warning {
            background: #fffbeb;
            border: 1px solid #f6e05e;
            color: #b7791f;
        }

        .alert-danger {
            background: #fed7d7;
            border: 1px solid #feb2b2;
            color: #c53030;
        }

        .backup-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            margin-bottom: 1rem;
        }

        .backup-info {
            flex: 1;
        }

        .backup-info .name {
            font-weight: 600;
            color: #2d3748;
        }

        .backup-info .details {
            color: #718096;
            font-size: 0.9rem;
        }

        .backup-actions {
            display: flex;
            gap: 0.5rem;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .settings-nav {
                flex-direction: column;
            }
            
            .backup-item {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-shield-alt"></i>
            RiskGuard Pro
        </div>
        <div class="nav-links">
            <a href="index.php"><i class="fas fa-home"></i> Dashboard</a>
            <a href="clients.php"><i class="fas fa-building"></i> Clients</a>
            <a href="risks.php"><i class="fas fa-exclamation-triangle"></i> Risks</a>
            <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
            <a href="login.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>

    <div class="container">
        <!-- Settings Header -->
        <div class="settings-header">
            <h1><i class="fas fa-cogs"></i> System Settings</h1>
            <p>Configure and manage your RiskGuard Pro system preferences</p>
        </div>

        <!-- Settings Navigation -->
        <div class="settings-nav">
            <button class="active" onclick="showSection('general')">
                <i class="fas fa-cog"></i> General
            </button>
            <button onclick="showSection('security')">
                <i class="fas fa-shield-alt"></i> Security
            </button>
            <button onclick="showSection('notifications')">
                <i class="fas fa-bell"></i> Notifications
            </button>
            <button onclick="showSection('integrations')">
                <i class="fas fa-plug"></i> Integrations
            </button>
            <button onclick="showSection('backup')">
                <i class="fas fa-database"></i> Backup
            </button>
            <button onclick="showSection('advanced')">
                <i class="fas fa-tools"></i> Advanced
            </button>
        </div>

        <!-- Settings Content -->
        <div class="settings-content">
            <!-- General Settings -->
            <div id="general" class="settings-section active">
                <h2 class="section-title">
                    <i class="fas fa-cog"></i>
                    General Settings
                </h2>

                <form>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="companyName">Company Name</label>
                            <input type="text" id="companyName" value="RiskGuard Pro">
                        </div>
                        <div class="form-group">
                            <label for="timezone">Timezone</label>
                            <select id="timezone">
                                <option value="UTC">UTC</option>
                                <option value="EST" selected>Eastern Time</option>
                                <option value="PST">Pacific Time</option>
                                <option value="GMT">Greenwich Mean Time</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="language">Default Language</label>
                            <select id="language">
                                <option value="en" selected>English</option>
                                <option value="es">Spanish</option>
                                <option value="fr">French</option>
                                <option value="de">German</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="currency">Default Currency</label>
                            <select id="currency">
                                <option value="USD" selected>US Dollar ($)</option>
                                <option value="EUR">Euro (€)</option>
                                <option value="GBP">British Pound (£)</option>
                                <option value="CAD">Canadian Dollar (C$)</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="dateFormat">Date Format</label>
                        <select id="dateFormat">
                            <option value="MM/DD/YYYY" selected>MM/DD/YYYY</option>
                            <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                            <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save General Settings
                    </button>
                </form>
            </div>

            <!-- Security Settings -->
            <div id="security" class="settings-section">
                <h2 class="section-title">
                    <i class="fas fa-shield-alt"></i>
                    Security Settings
                </h2>

                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    These settings affect system-wide security policies and user access controls.
                </div>

                <form>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="sessionTimeout">Session Timeout (minutes)</label>
                            <input type="number" id="sessionTimeout" value="30" min="5" max="480">
                        </div>
                        <div class="form-group">
                            <label for="passwordPolicy">Password Policy</label>
                            <select id="passwordPolicy">
                                <option value="basic">Basic (8+ characters)</option>
                                <option value="standard" selected>Standard (8+ chars, mixed case, numbers)</option>
                                <option value="strict">Strict (12+ chars, mixed case, numbers, symbols)</option>
                            </select>
                        </div>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="requireMFA" checked>
                        <label for="requireMFA">Require Multi-Factor Authentication for all users</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="auditLogging" checked>
                        <label for="auditLogging">Enable comprehensive audit logging</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="ipWhitelist">
                        <label for="ipWhitelist">Enable IP address whitelisting</label>
                    </div>

                    <div class="form-group">
                        <label for="allowedIPs">Allowed IP Addresses (one per line)</label>
                        <textarea id="allowedIPs" rows="4" placeholder="192.168.1.0/24&#10;10.0.0.0/8"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-shield-alt"></i> Update Security Settings
                    </button>
                </form>
            </div>

            <!-- Notification Settings -->
            <div id="notifications" class="settings-section">
                <h2 class="section-title">
                    <i class="fas fa-bell"></i>
                    Notification Settings
                </h2>

                <form>
                    <h3 style="margin-bottom: 1rem; color: #2d3748;">Email Notifications</h3>
                    
                    <div class="checkbox-group">
                        <input type="checkbox" id="emailCriticalRisks" checked>
                        <label for="emailCriticalRisks">Critical risk alerts</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="emailWeeklyReports" checked>
                        <label for="emailWeeklyReports">Weekly summary reports</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="emailSystemUpdates">
                        <label for="emailSystemUpdates">System updates and maintenance</label>
                    </div>

                    <h3 style="margin: 2rem 0 1rem; color: #2d3748;">SMS Notifications</h3>
                    
                    <div class="checkbox-group">
                        <input type="checkbox" id="smsEmergency">
                        <label for="smsEmergency">Emergency alerts only</label>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="emailServer">SMTP Server</label>
                            <input type="text" id="emailServer" value="smtp.company.com">
                        </div>
                        <div class="form-group">
                            <label for="emailPort">SMTP Port</label>
                            <input type="number" id="emailPort" value="587">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Notification Settings
                    </button>
                </form>
            </div>

            <!-- Integrations -->
            <div id="integrations" class="settings-section">
                <h2 class="section-title">
                    <i class="fas fa-plug"></i>
                    Third-Party Integrations
                </h2>

                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Connect RiskGuard Pro with external systems and services.
                </div>

                <form>
                    <h3 style="margin-bottom: 1rem; color: #2d3748;">API Integrations</h3>
                    
                    <div class="form-group">
                        <label for="apiKey">API Key</label>
                        <input type="password" id="apiKey" value="rg_live_sk_1234567890abcdef">
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="enableSlack" checked>
                        <label for="enableSlack">Slack Integration</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="enableTeams">
                        <label for="enableTeams">Microsoft Teams Integration</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="enableJira">
                        <label for="enableJira">Jira Integration</label>
                    </div>

                    <h3 style="margin: 2rem 0 1rem; color: #2d3748;">Database Connections</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="dbHost">Database Host</label>
                            <input type="text" id="dbHost" value="localhost">
                        </div>
                        <div class="form-group">
                            <label for="dbPort">Database Port</label>
                            <input type="number" id="dbPort" value="3306">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plug"></i> Update Integrations
                    </button>
                </form>
            </div>

            <!-- Backup Settings -->
            <div id="backup" class="settings-section">
                <h2 class="section-title">
                    <i class="fas fa-database"></i>
                    Backup & Recovery
                </h2>

                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    Regular backups are essential for data protection. Configure automatic backups below.
                </div>

                <form>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="backupFrequency">Backup Frequency</label>
                            <select id="backupFrequency">
                                <option value="daily" selected>Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="monthly">Monthly</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="backupTime">Backup Time</label>
                            <input type="time" id="backupTime" value="02:00">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="backupLocation">Backup Location</label>
                        <select id="backupLocation">
                            <option value="local" selected>Local Storage</option>
                            <option value="aws">Amazon S3</option>
                            <option value="azure">Azure Blob Storage</option>
                            <option value="gcp">Google Cloud Storage</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Backup Settings
                    </button>
                    
                    <button type="button" class="btn btn-secondary" style="margin-left: 1rem;">
                        <i class="fas fa-download"></i> Create Backup Now
                    </button>
                </form>

                <h3 style="margin: 2rem 0 1rem; color: #2d3748;">Recent Backups</h3>
                
                <div class="backup-item">
                    <div class="backup-info">
                        <div class="name">Full System Backup</div>
                        <div class="details">Created: June 15, 2025 at 2:00 AM • Size: 2.4 GB</div>
                    </div>
                    <div class="backup-actions">
                        <button class="btn btn-secondary">
                            <i class="fas fa-download"></i> Download
                        </button>
                        <button class="btn btn-primary">
                            <i class="fas fa-undo"></i> Restore
                        </button>
                    </div>
                </div>

                <div class="backup-item">
                    <div class="backup-info">
                        <div class="name">Database Backup</div>
                        <div class="details">Created: June 14, 2025 at 2:00 AM • Size: 1.8 GB</div>
                    </div>
                    <div class="backup-actions">
                        <button class="btn btn-secondary">
                            <i class="fas fa-download"></i> Download
                        </button>
                        <button class="btn btn-primary">
                            <i class="fas fa-undo"></i> Restore
                        </button>
                    </div>
                </div>
            </div>

            <!-- Advanced Settings -->
            <div id="advanced" class="settings-section">
                <h2 class="section-title">
                    <i class="fas fa-tools"></i>
                    Advanced Settings
                </h2>

                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Warning:</strong> These settings are for advanced users only. Incorrect configuration may affect system performance.
                </div>

                <form>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="cacheTimeout">Cache Timeout (seconds)</label>
                            <input type="number" id="cacheTimeout" value="3600">
                        </div>
                        <div class="form-group">
                            <label for="maxFileSize">Max Upload Size (MB)</label>
                            <input type="number" id="maxFileSize" value="50">
                        </div>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="debugMode">
                        <label for="debugMode">Enable debug mode</label>
                    </div>

                    <div class="checkbox-group">
                        <input type="checkbox" id="maintenanceMode">
                        <label for="maintenanceMode">Enable maintenance mode</label>
                    </div>

                    <div class="form-group">
                        <label for="customCSS">Custom CSS</label>
                        <textarea id="customCSS" rows="6" placeholder="/* Add your custom CSS here */"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Advanced Settings
                    </button>
                    
                    <button type="button" class="btn btn-danger" style="margin-left: 1rem;">
                        <i class="fas fa-trash"></i> Reset to Defaults
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function showSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.settings-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Remove active class from all nav buttons
            document.querySelectorAll('.settings-nav button').forEach(button => {
                button.classList.remove('active');
            });
            
            // Show selected section
            document.getElementById(sectionId).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }

        // Form submission handlers
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                alert('Settings saved successfully!');
            });
        });
    </script>
</body>
</html>

